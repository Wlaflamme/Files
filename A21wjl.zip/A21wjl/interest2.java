/*******************************************
Programmer: Will Laflamme
Date:12/1/17
Output:the rate of interest
*******************************************/
public class interest2 extends interest//class declaration
{
	int intrest;//variable
	public interest2(int intrst)//constructor
	{
		intrest=intrst;//variable
	}

	public int getRateOfInterest()//method
	{
		return intrest;//return
	}
}