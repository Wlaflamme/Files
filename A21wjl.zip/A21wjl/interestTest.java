/*******************************************
Programmer: Will Laflamme
Date:12/1/17
Output:print rate of interest
*******************************************/
public class interestTest//class declaration
{
	public static void main(String[]args)//main method
	{
		interest1  int1=new interest1(7);//create object
		interest2  int2=new interest2(8);//create object

		System.out.println("Rate of interest: "+int1.getRateOfInterest()+"%\nRate of interest: "+int2.getRateOfInterest()+"%");//print statement
	}
}