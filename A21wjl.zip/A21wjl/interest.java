/*******************************************
Programmer: Will Laflamme
Date:12/1/17
Output:method for rate of interest
*******************************************/
public abstract class interest//class declaration
{
	public abstract int getRateOfInterest();//method
}