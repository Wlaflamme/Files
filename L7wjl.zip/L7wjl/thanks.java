/*******************************************
Programmer: Will Laflamme
Date:12/6/17
Output:create thanksgiving method
*******************************************/
public abstract class thanks//class declaration
{
	public abstract String thanksgiving();//method
}