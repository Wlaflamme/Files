/*******************************************
Programmer: Will Laflamme
Date:12/6/17
Output:test thanksgiving method
*******************************************/
public class thanksgivingTest//class declaration
{
	public static void main(String[]args)//main method
	{
		giving tg=new giving();//create object

		System.out.println(tg.thanksgiving());//print statement
	}
}