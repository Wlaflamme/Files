/*******************************************
Programmer: Will Laflamme
Date:12/6/17
Output:uses thanksgiving method
*******************************************/
public class giving extends thanks//class declaration
{
	public String thanksgiving()//method
	{
		return "Hello... Have a good THANKSGIVING!!!";//return statement
	}
}