/*******************************************
Programmer: Will Laflamme
Date:10/11/17
Output:the ultimate math tutor
*******************************************/
import java.util.Scanner;//import scanner
public class L4_2wjl//class declaration
{
	public static void main(String[] args)//main method
	{
		int lvl;//int vsriable
		String m;//string variable
		char select;//char variable

		Scanner scan=new Scanner(System.in);//create scanner object

		Random1wjl num1 = new Random1wjl();//create Random1wjl object
		Random2wjl num2 = new Random2wjl();//create Random2wjl object

		System.out.print("(Select 1: for level 1 or 2: for level 2): ");//print statement
		lvl=scan.nextInt();//assign input to variable


		if(lvl==1)//if statement
		{
			System.out.print("Select +, or -: ");//print statement
			m=scan.next();//assign input to variable

			select = m.charAt(0);//assign first of m to select

			if(select=='+')//if statement
			{
				num1.plus();//call num1 plus method
			}
			else//else statement
			{
				num1.minus();//call num1 minus method
			}
		}

		else//else statement
		{
			System.out.print("Select +, or -: ");//print statement
			m=scan.next();//assign input to variable

			select = m.charAt(0);//assign first of m to select

			if(select=='+')//if statement
			{
				num2.plus();//call num2 plus method
			}
			else//else statement
			{
				num2.minus();//call num2 minus method
			}
		}
	}
}