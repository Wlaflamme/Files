/*******************************************
Programmer: Will Laflamme
Date:10/11/17
Output:methods for the ultimate math tutor
*******************************************/
import java.util.Random;//import random
import java.util.Scanner;//import scanner
public class Random1wjl//class declaration
{
	private int i;//private variable
	private int j;//private variable
	private int sum1;//private variable
	private int sum2;//private variable
	private int c=0;//private variable
	private int ic=0;//private variable

	Random rNum=new Random();//create random object
	Scanner scan=new Scanner(System.in);//create scanner object


	public void ranNum()//method
	{
		i=0+rNum.nextInt(9);//assign random value to variable
		j=0+rNum.nextInt(9);//assign random value to variable
	}

	public void plus()//method
	{
		for(int k=0;k<10;k++)//for loop
		{
			this.ranNum();//call ranNum method
			sum1=i+j;//assign value to variable
			System.out.print("What is your answer?\n"+i+"+"+j+"=");//print statement
			sum2=scan.nextInt();//assign input to variable

			this.compare();//call compare method
		}
		this.tally();//call tally method
	}

	public void minus()//method
	{
		for(int k=0;k<10;k++)//for loop
		{
			this.ranNum();//call ranNum method
			sum1=i-j;//assign value to variable
			System.out.print("What is your answer?\n"+i+"-"+j+"=");//print statement
			sum2=scan.nextInt();//assign input to variable

			this.compare();//call compare method
		}
		this.tally();//call tally method

	}

	public void compare()//method
	{
		if(sum1==sum2)//if statement
		{
			System.out.println("Correct!");//print statement
			c++;//add one to c
		}

		else//else statement
		{
			System.out.println("Wrong! The correct answer is "+sum1);//print statement
			ic++;//add one to ic
		}
	}

	public void tally()//method
	{
		System.out.println("You solved 10 problems.\nYou got "+c+" correct answers!\nYou got "+ic+" wrong answers!");//print statement
	}
}